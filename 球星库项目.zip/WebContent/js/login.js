/**
 * 
 */
	var num1;
	var num2;
	var result;
	
	num1 = Math.floor(Math.random() * 10);
	num2 = Math.floor(Math.random() * 10);
	
	var op_ch = [ '+', '-', '*', '/' ];
	while (1) {
		var opch = Math.floor(Math.random() * 10);
		if (opch <= 3) {
			break;
		}
	}
	if (opch == 0) {
		result = num1 + num2;
	} else if (opch == 1) {
		result = num1 - num2;
	} else if (opch = 2) {
		result = num1 * num2;
	} else {
		result = num1 / num2;
	}
	
	window.onload=function(){
	var txt = new String();
	txt = num1 + op_ch[opch] + num2 + '=' + '?';
	document.getElementById("checkbox").innerText = txt;
	}

function form_submit(thisForm) {
	with (thisForm) {
		var c=check.value;
		if (pwd.value == "") {
			alert("密码不可以为空!");
			return false;
		} else if (c!=result) {
			alert(result);
			alert("验证码错误！");
			return false;
		} else {
			return true;
		}

	}

}