function quitRecord()
{
	if(confirm("确定要退出吗？"))
	{
		return true;
	}
	else
	{
		return false;
	}
}

