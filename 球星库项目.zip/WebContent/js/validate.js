function deleteRecord()
{
	if(confirm("确定要解雇吗？"))
	{
		return true;
	}
	else
	{
		return false;
	}
}

