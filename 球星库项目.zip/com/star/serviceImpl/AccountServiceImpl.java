package com.star.serviceImpl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.star.dao.IAccountDao;
import com.star.daoimpl.AccountDaoImpl;
import com.star.pojo.Account;
import com.star.service.IAccountService;
import com.tjrac.contact.util.ConnectionManager;

public class AccountServiceImpl implements IAccountService {
	public int addAccount(Account account) {
		ConnectionManager connectionManager = new ConnectionManager();
		Connection connection =connectionManager.getConnection();
		IAccountDao iAccountDao = new AccountDaoImpl();
		int affectedRows = -1;
		try {
			affectedRows = iAccountDao.insertAccount(account, connection);
			return affectedRows;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return affectedRows;
		}finally {
			connectionManager.closeConnection(connection);}
	}

	@Override
	public List<Account> findAllAccount() {
		ConnectionManager connectionManager = new ConnectionManager();
		Connection connection = connectionManager.getConnection();
		List<Account> accountList = new ArrayList<Account>();
		IAccountDao iAccountDao = new AccountDaoImpl();
		try {
			ResultSet rs = iAccountDao.selectAllAccount(connection);
			while (rs.next()) {
				Account account = new Account(rs.getString("cid"));
				accountList.add(account);
			}
			return accountList;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} finally {
			connectionManager.closeConnection(connection);
		}
	}

	@Override
	public Account judgeAccountIsExist(Account account) {
		ConnectionManager connectionManager = new ConnectionManager();
		Connection connection = connectionManager.getConnection();
		IAccountDao iAccountDao = new AccountDaoImpl();
		Account account1 = null;
		ResultSet rs = null;
		try {
			rs = iAccountDao.checkLogin(account, connection);
			if(rs.next())
			{
				account1 = new Account();
				account1.setCid(rs.getString(1));
				account1.setPwd(rs.getString(2));
				return account1;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return account1;
		}finally {
			connectionManager.closeConnection(connection);
		}
		return account1;
	}

	@Override
	public int updateAccountPsw(Account account, String pwd, String cid) {
		ConnectionManager connectionManager = new ConnectionManager();
		Connection connection =connectionManager.getConnection();
		IAccountDao iAccountDao = new AccountDaoImpl();
		int affectedRows = -1;
		try {
			affectedRows = iAccountDao.updatePassword(pwd, cid, connection);
			return affectedRows;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return affectedRows;
		}finally {
			connectionManager.closeConnection(connection);
		}
	}
}
