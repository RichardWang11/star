package com.star.serviceImpl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.star.dao.IGroupDao;
import com.star.daoimpl.GroupDaoImpl;
import com.star.pojo.Group;
import com.star.service.IGroupService;
import com.tjrac.contact.util.ConnectionManager;

public class GroupServiceImpl implements IGroupService {

	@Override
	public int addGroup(Group group) {
		ConnectionManager connectionManager = new ConnectionManager();
		Connection connection =connectionManager.getConnection();
		IGroupDao iGroupDao = new GroupDaoImpl();
		int affectedRows = -1;
		try {
			affectedRows = iGroupDao.insertGroups(group, connection);
			return affectedRows;
		} catch (Exception e) {
			e.printStackTrace();
			return affectedRows;
		}finally {
		connectionManager.closeConnection(connection);}
	}

	@Override
	public List<Group> findAllGroups() {
		ConnectionManager connectionManager = new ConnectionManager();
		Connection connection = connectionManager.getConnection();
		List<Group> groupList = new ArrayList<Group>();
		IGroupDao iGroupDao = new GroupDaoImpl();
		try {
			ResultSet rs = iGroupDao.selectAllGroups(connection);
			while (rs.next()) {
				Group group = new Group(rs.getInt("gid"), rs.getString("gname"));
				groupList.add(group);
			}
			return groupList;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} finally {
			connectionManager.closeConnection(connection);
		}
	}

	@Override
	public int updateGroup(Group group, int gid) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Group findGroupByGid(int gid) {
		// TODO Auto-generated method stub
		return null;
	}

}
