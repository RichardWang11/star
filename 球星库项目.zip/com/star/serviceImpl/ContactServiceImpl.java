package com.star.serviceImpl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.star.dao.IContactDao;
import com.star.daoimpl.ContactDaoImpl;
import com.star.pojo.Contact;
import com.star.service.IContactService;

import com.tjrac.contact.util.ConnectionManager;

public class ContactServiceImpl implements IContactService {

	@Override
	public int addContact(Contact contact) {
		ConnectionManager connectionManager = new ConnectionManager();
		Connection connection =connectionManager.getConnection();
		int affectedRows = -1;
		//TransactionManager transactionManager = new TransactionManager();
		try {
			//1,完成联系人基本信息添加
		    IContactDao iContactDao = new ContactDaoImpl();
		    affectedRows = iContactDao.insertContact(contact, connection);
			//2，完成用户登录账号添加
			//提交事务
			//transactionManager.commitTranscation(connection);
			return affectedRows;
		} catch (Exception e) {
			e.printStackTrace();
			//出现异常，回滚事务
			//transactionManager.rollbackTranscation(connection);
			return affectedRows;
		}finally {
		connectionManager.closeConnection(connection);
		}
	}

	@Override
	public int removeContactBySid(int sid) {
		ConnectionManager connectionManager = new ConnectionManager();
		Connection connection =connectionManager.getConnection();
		IContactDao iContactDao = new ContactDaoImpl();
		int affectedRows = -1;
		try {
			affectedRows = iContactDao.deleteContactBySid(sid, connection);
			return affectedRows;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return affectedRows;
		}finally {
			connectionManager.closeConnection(connection);
		}
	}

	@Override
	public List<Contact> findAllContact() {
		ConnectionManager connectionManager = new ConnectionManager();
		Connection connection =connectionManager.getConnection();
		List<Contact> contactList = new ArrayList<Contact>();
		IContactDao iContactDao = new ContactDaoImpl();
		try {
			ResultSet rs = iContactDao.selectAllContact(connection);
			while(rs.next()) {
				Contact contact1 = new Contact(rs.getString("cid"),rs.getInt("sid"),rs.getString("cname"),rs.getString("img"),rs.getInt("rank"),rs.getString("nation"),rs.getInt("gid"),rs.getString("gname"));
				contactList.add(contact1);
			}
			return contactList;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}finally {
			connectionManager.closeConnection(connection);
		}
	}

	@Override
	public List<Contact> findContactByCid(String cid) {
		ConnectionManager connectionManager = new ConnectionManager();
		Connection connection =connectionManager.getConnection();
		List<Contact> contactList = new ArrayList<Contact>();
		IContactDao iContactDao = new ContactDaoImpl();
		try {
			ResultSet rs = iContactDao.selectContactByCid(cid, connection);
			while(rs.next()) {
				Contact contact1 = new Contact(rs.getString("cid"),rs.getInt("sid"),rs.getString("cname"),rs.getString("img"),rs.getInt("rank"),rs.getString("nation"),rs.getInt("gid"),rs.getString("gname"));
				contactList.add(contact1);
			}
			return contactList;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}finally {
			connectionManager.closeConnection(connection);
		}
	}

	@Override
	public Contact findContactBySid(int sid) {
		ConnectionManager connectionManager = new ConnectionManager();
		Connection connection =connectionManager.getConnection();
		IContactDao iContactDao = new ContactDaoImpl();
		Contact contact = null;
		try {
			ResultSet rs = iContactDao.selectContactBySid( sid, connection);
			if(rs.next()) {
				contact = new Contact();
				contact.setCid(rs.getString("cid"));
				contact.setSid(rs.getInt("sid"));
				contact.setCname(rs.getString("cname"));
				contact.setImg(rs.getString("img"));
				contact.setRank(rs.getInt("rank"));
				contact.setNation(rs.getString("nation"));
				contact.setGid(rs.getInt("gid"));
				contact.setGname(rs.getString("gname"));
				return contact;
			}else {
			    return contact;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return contact;
		}finally {
		connectionManager.closeConnection(connection);
		}
	}

	@Override
	public List<Contact> findContactByCname(String cid, String cname) {
		ConnectionManager connectionManager = new ConnectionManager();
		Connection connection =connectionManager.getConnection();
		List<Contact> contactList = new ArrayList<Contact>();
		IContactDao iContactDao = new ContactDaoImpl();
		try {
			ResultSet rs =iContactDao.selectContactByCname(cid,cname, connection);
			while(rs.next()) {
				Contact contact1 = new Contact(rs.getString("cid"),rs.getInt("sid"),rs.getString("cname"),rs.getString("img"),rs.getInt("rank"),rs.getString("nation"),rs.getInt("gid"),rs.getString("gname"));
				contactList.add(contact1);
			}
			return contactList;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return contactList;
		}finally {
			connectionManager.closeConnection(connection);
		}
	}

	@Override
	public List<Contact> findContactByGname(String cid, String gname) {
		ConnectionManager connectionManager = new ConnectionManager();
		Connection connection =connectionManager.getConnection();
		List<Contact> contactList = new ArrayList<Contact>();
		IContactDao iContactDao = new ContactDaoImpl();
		try {
			ResultSet rs =iContactDao.selectAllContactByGname(cid, gname, connection);
			while(rs.next()) {
				Contact contact1 = new Contact(rs.getString("cid"),rs.getInt("sid"),rs.getString("cname"),rs.getString("img"),rs.getInt("rank"),rs.getString("nation"),rs.getInt("gid"),rs.getString("gname"));
				contactList.add(contact1);
			}
			return contactList;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return contactList;
		}finally {
			connectionManager.closeConnection(connection);
		}
	}

}
