package com.star.pojo;

public class Contact {
	String cid;
	int sid;
	String cname;
	String img;
	int rank;
	String nation;
	int gid;
	String gname;
	
	public String getCid() {
		return cid;
	}
	public void setCid(String cid) {
		this.cid = cid;
	}
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
	public int getRank() {
		return rank;
	}
	public void setRank(int rank) {
		this.rank = rank;
	}
	public String getNation() {
		return nation;
	}
	public void setNation(String nation) {
		this.nation = nation;
	}
	public int getGid() {
		return gid;
	}
	public void setGid(int gid) {
		this.gid = gid;
	}
	public String getGname() {
		return gname;
	}
	public void setGname(String gname) {
		this.gname = gname;
	}
	@Override
	public String toString() {
		return "Contact [cid=" + cid + ", sid=" + sid + ", cname=" + cname + ", img=" + img + ", rank=" + rank
				+ ", nation=" + nation + ", gid=" + gid + ", gname=" + gname + "]";
	}
	public Contact() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Contact(String cid, int sid, String cname, String img, int rank, String nation, int gid, String gname) {
		super();
		this.cid = cid;
		this.sid = sid;
		this.cname = cname;
		this.img = img;
		this.rank = rank;
		this.nation = nation;
		this.gid = gid;
		this.gname = gname;
	}
	public Contact(String cid, String cname, String img, int rank, String nation, int gid, String gname) {
		super();
		this.cid = cid;
		this.cname = cname;
		this.img = img;
		this.rank = rank;
		this.nation = nation;
		this.gid = gid;
		this.gname = gname;
	}

}
