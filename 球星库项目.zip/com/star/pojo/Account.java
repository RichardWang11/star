package com.star.pojo;

public class Account {
	String cid;
	String pwd;
	public String getCid() {
		return cid;
	}
	public void setCid(String cid) {
		this.cid = cid;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	@Override
	public String toString() {
		return "Account [cid=" + cid + ", pwd=" + pwd + "]";
	}
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Account(String cid, String pwd) {
		super();
		this.cid = cid;
		this.pwd = pwd;
	}
	
	public Account(String cid) {
		super();
		this.cid = cid;
	}
}
