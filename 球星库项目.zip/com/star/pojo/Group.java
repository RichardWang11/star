package com.star.pojo;

public class Group {
	int gid;
	String gname;
	public int getGid() {
		return gid;
	}
	public void setGid(int gid) {
		this.gid = gid;
	}
	public String getGname() {
		return gname;
	}
	public void setGname(String gname) {
		this.gname = gname;
	}
	@Override
	public String toString() {
		return "Group [gid=" + gid + ", gname=" + gname + "]";
	}
	public Group() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Group(int gid, String gname) {
		super();
		this.gid = gid;
		this.gname = gname;
	}
	public Group(String gname) {
		super();
		this.gname = gname;
	}

}
