package com.star.service;

import java.util.List;

import com.star.pojo.Contact;


public interface IContactService {
	int addContact(final Contact contact);
	int removeContactBySid(final int sid);
	List<Contact> findAllContact();
	
	List<Contact> findContactByCid(final String cid);
	Contact findContactBySid(final int sid);
	
	List<Contact> findContactByCname(final String cid,final String cname);
	
	List<Contact> findContactByGname(final String cid,final String gname);
}
