package com.star.service;

import java.util.List;

import com.star.pojo.Group;



public interface IGroupService {
	int addGroup(final Group group);
	List<Group> findAllGroups();
	int updateGroup(final Group group,final int gid);
	
	Group findGroupByGid(final int gid);

}
