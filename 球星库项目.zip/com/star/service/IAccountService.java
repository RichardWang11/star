package com.star.service;

import java.util.List;

import com.star.pojo.Account;


public interface IAccountService {
	int addAccount(final Account account);
	
	int updateAccountPsw(final Account account,final String pwd,final String cid);
	
	Account judgeAccountIsExist(final Account account);
	
	List<Account> findAllAccount();
}
