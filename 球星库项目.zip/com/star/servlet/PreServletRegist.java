package com.star.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.star.pojo.Account;
import com.star.service.IAccountService;
import com.star.serviceImpl.AccountServiceImpl;



/**
 * Servlet implementation class PreServletRegist
 */
@WebServlet("/PreServletRegist")
public class PreServletRegist extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	// 预定义的用户名
		public String[] usernameList;

		@Override
		public void init(ServletConfig config) throws ServletException {
			IAccountService iAccountService = new AccountServiceImpl();
			List<Account> accountList = iAccountService.findAllAccount();
			usernameList = new String[] { "", "", "", "" ,""};
			int i=0;
			while(i<accountList.size())
			{
				usernameList[i] = accountList.get(i).getCid();
				i++;
			}
		}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 设置返回内容类型
				response.setContentType("text/xml");
				// 设置不缓存
				response.setHeader("Cache-Control", "no-cache");

				String cid = request.getParameter("cid");

				// 设置xml格式
				String xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";

				if ("".equals(cid) || null == cid) {
					xml += "<message><info>username is required</info><flag>required</flag></message>";
				} else if (this.isContain(cid)) {
					xml += "<message><info>The username has exsites,please choose other username</info><flag>exsites</flag></message>";
				} else {
					xml += "<message><info>The username is approved</info><flag>approved</flag></message>";
				}
				response.getWriter().write(xml);
			}

			private boolean isContain(String cid) {
				for (int i = 0; i < usernameList.length; i++) {
					if (usernameList[i].equals(cid)) {
						return true;
					} else {
						continue;
					}
				}
				return false;
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
