package com.star.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.star.pojo.Group;
import com.star.service.IGroupService;
import com.star.serviceImpl.GroupServiceImpl;




@WebServlet("/AddGroupServlet")
public class AddGroupServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddGroupServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		
		String gname = request.getParameter("gname");
		Group group = new Group(gname);
		IGroupService iGroupService = new GroupServiceImpl();
		int result = iGroupService.addGroup(group);
		
		if(result>0)
		{
			request.getRequestDispatcher("showGroups.jsp").forward(request, response);
		}
		else
		{
			out.println("<script>alert('添加异常');location.href='addGroup.html'</script>");
		}
		
	}

}
