package com.star.servlet;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.star.pojo.Contact;
import com.star.service.IContactService;
import com.star.serviceImpl.ContactServiceImpl;


/**
 * Servlet implementation class AddContactServlet
 */
@WebServlet("/AddContactServlet")
public class AddContactServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddContactServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		DiskFileItemFactory disk = new DiskFileItemFactory();
		ServletFileUpload servletfileupload= new ServletFileUpload(disk);
		servletfileupload.setHeaderEncoding("utf-8");
		servletfileupload.setFileSizeMax(10*1024*1024);
		String cid=null;
		String cname=null;
		String img=null;
		String rank=null;
		String nation=null;
		String gname=null;
		String gid=null;
		
		PrintWriter out = response.getWriter();
		
		try {
			List<FileItem> parseRequest =servletfileupload.parseRequest(request);
			for (FileItem fileItem : parseRequest) {
				if(fileItem.isFormField())
				{
					String name = fileItem.getFieldName();
					if(name.equals("cid"))
					{
						cid =new String(fileItem.getString("utf-8"));
					}
					if(name.equals("cname"))
					{
						cname =new String(fileItem.getString("utf-8"));
					}
					if(name.equals("rank"))
					{
						rank=new String(fileItem.getString("utf-8"));
					}
					if(name.equals("nation"))
					{
						nation=new String(fileItem.getString("utf-8"));
					}
				
					if(name.equals("gname"))
					{
						 gname =new String(fileItem.getString("utf-8"));
					}
					if(name.equals("gid"))
					{
						 gid =new String(fileItem.getString("utf-8"));
					}
				}
				if(!(fileItem.isFormField()))
				{
					img =fileItem.getName();
					if(!(img.endsWith(".jpg")||img.endsWith(".png")||img.endsWith(".jpeg")))
					{
						request.setAttribute("error", "不能上传此文件类型");
						request.getRequestDispatcher("WEB-INF/page/addpro.jsp").forward(request, response);
						return;
					}
					InputStream inputstream =fileItem.getInputStream();
					File file =new File("D:/test/"+fileItem.getName());
					FileOutputStream fos = new FileOutputStream(file);
					int lean = 0;
					byte[] buffer=new byte[1024];
					while((lean=inputstream.read(buffer))!=-1)
					{
						fos.write(buffer, 0, lean);
					}
					fos.close();
					inputstream.close();
				}
			}
		} catch (FileUploadException e) {
			e.printStackTrace();
		}

		int Rank = Integer.parseInt(rank);
	
		int Gid = Integer.parseInt(gid);
	
		
		Contact contact = new Contact( cid, cname, img, Rank, nation, Gid, gname);
		IContactService iContactService = new ContactServiceImpl();
		 int result = iContactService.addContact(contact);
		 if(result>0)
		 {
//			 request.getRequestDispatcher("showContact.jsp").forward(request, response);
			 response.sendRedirect("showContact.jsp");
		 }else
		 {
			 out.println("<script>alert('联系人信息添加异常');location.href='addcontact.jsp'</script>");
		 }
	}

}
