package com.star.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.star.pojo.Account;
import com.star.service.IAccountService;
import com.star.serviceImpl.AccountServiceImpl;


/**
 * Servlet implementation class LoginServ
 */
@WebServlet("/LoginServ")
public class LoginServ extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServ() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		String cid = request.getParameter("cid");
		String pwd = request.getParameter("pwd");
		
		System.out.println("用户名"+cid+","+pwd);
		IAccountService iAccountService = new AccountServiceImpl();
		Account account1 = new Account(cid, pwd);
		Account result = iAccountService.judgeAccountIsExist(account1);
		HttpSession session = request.getSession();
		if(result!=null)
		{
			session.setAttribute("userNow", cid);
			request.getRequestDispatcher("showContact.jsp").forward(request, response);
		}
		else {
			out.println("<script>alert('登陆失败，请重新登录');location.href='LOGIN.jsp'</script>");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
