package com.star.daoimpl;

import java.sql.Connection;
import java.sql.ResultSet;

import com.star.dao.IContactDao;
import com.star.pojo.Contact;
import com.tjrac.contact.util.SQLManager;

public class ContactDaoImpl implements IContactDao {

	@Override
	public int insertContact(Contact contact, Connection connection) throws Exception {
		String strSQL="insert into contact(cid,cname,img,rank,nation,gid,gname) values(?,?,?,?,?,?,?)";
		Object[] params = new Object[] {contact.getCid(),contact.getCname(),contact.getImg(),contact.getRank(),contact.getNation(),contact.getGid(),contact.getGname()};
		SQLManager sqlManager = new SQLManager();
		return sqlManager.execUpdate(connection, strSQL, params);
	}

	@Override
	public ResultSet selectAllContactByGname(String cid, String gname, Connection connection) throws Exception {
		String strSQL = "select * from contact where cid=? and gname=?" ;
		Object[] params = new Object[] {cid,gname};
		SQLManager sqlManager = new SQLManager();
		return sqlManager.execQuery(connection, strSQL, params);
	}

	@Override
	public ResultSet selectContactByCname(String cid, String cname, Connection connection) throws Exception {
		String strSQL = "select * from contact where cid=? and cname=?" ;
		Object[] params = new Object[] {cid,cname};
		SQLManager sqlManager = new SQLManager();
		return sqlManager.execQuery(connection, strSQL, params);
	}

	@Override
	public ResultSet selectContactByCid(String cid, Connection connection) throws Exception {
		String strSQL = "select * from contact where cid=?" ;
		Object[] params = new Object[] {cid};
		SQLManager sqlManager = new SQLManager();
		return sqlManager.execQuery(connection, strSQL, params);
	}

	@Override
	public int updateContact(Contact contact, int sid, Connection connection) throws Exception {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteContactBySid(int sid, Connection connection) throws Exception {
		SQLManager sqlManager = new SQLManager();
		String strSQL = "delete from contact where sid=?";
		Object[] params = new Object[] { sid };
		int affectedRows = sqlManager.execUpdate(connection, strSQL, params);
		return affectedRows;
	}

	@Override
	public ResultSet selectAllContact(Connection connection) throws Exception {
		String strSQL = "select * from contact";
		Object[] params = new Object[] {};
		SQLManager sqlManager = new SQLManager();
		return sqlManager.execQuery(connection, strSQL, params);
	}

	@Override
	public ResultSet selectContactBySid(int sid, Connection connection) throws Exception {
		String strSQL = "select * from contact where sid=?" ;
		Object[] params = new Object[] {sid};
		SQLManager sqlManager = new SQLManager();
		return sqlManager.execQuery(connection, strSQL, params);
	}


}
