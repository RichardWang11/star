package com.star.daoimpl;

import java.sql.Connection;
import java.sql.ResultSet;

import com.star.dao.IGroupDao;
import com.star.pojo.Group;
import com.tjrac.contact.util.SQLManager;

public class GroupDaoImpl implements IGroupDao {

	@Override
	public int insertGroups(Group group, Connection connection) throws Exception {
		String strSQL = "insert into groups(gname) values(?)";
		Object[] params = new Object[] {group.getGname()};
		SQLManager sqlManager = new SQLManager();
		return sqlManager.execUpdate(connection, strSQL, params);
	}

	@Override
	public ResultSet selectAllGroups(Connection connection) throws Exception {
		String strSQL = "select * from groups";
		Object[] params = new Object[] {};
		SQLManager sqlManager = new SQLManager();
		return sqlManager.execQuery(connection, strSQL, params);
	}

	@Override
	public int updateGroups(Group group, int gid, Connection connection) throws Exception {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public ResultSet selectGroupByGname(int gname, Connection connection) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
