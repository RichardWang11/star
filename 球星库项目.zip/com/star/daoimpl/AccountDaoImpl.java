package com.star.daoimpl;

import java.sql.Connection;
import java.sql.ResultSet;

import com.star.dao.IAccountDao;
import com.star.pojo.Account;
import com.tjrac.contact.util.SQLManager;

public class AccountDaoImpl implements IAccountDao {

	@Override
	public int insertAccount(Account account, Connection connection) throws Exception {
		String strSQL = "insert into account(cid,pwd) values(?,?)";
		Object[] params = new Object[] { account.getCid(), account.getPwd() };
		SQLManager sqlManager = new SQLManager();
		return sqlManager.execUpdate(connection, strSQL, params);
	}

	@Override
	public ResultSet checkLogin(Account account, Connection connection) throws Exception {
		String strSQL = "select * from account where cid=? and pwd=?";
		Object[] params = new Object[] { account.getCid(), account.getPwd() };
		SQLManager sqlManager = new SQLManager();
		return sqlManager.execQuery(connection, strSQL, params);
	}

	@Override
	public ResultSet selectAllAccount(Connection connection) {
		String strSQL = "select cid from account ";
		Object[] params = new Object[] { };
		SQLManager sqlManager = new SQLManager();
		return sqlManager.execQuery(connection, strSQL, params);
	}

	@Override
	public int updatePassword(String pwd, String cid, Connection connection) throws Exception {
		String strSQL = "update account set pwd=? where cid=?";
		Object[] params = new Object[] { pwd, cid };
		SQLManager sqlManager = new SQLManager();
		return sqlManager.execUpdate(connection, strSQL, params);
	}



}
