package com.star.dao;

import java.sql.Connection;
import java.sql.ResultSet;

import com.star.pojo.Contact;


public interface IContactDao {
	
	public abstract int insertContact(final Contact contact,final Connection connection) throws Exception;
	public abstract ResultSet selectAllContactByGname(final String cid,final String gname,final Connection connection) throws Exception;
	public abstract ResultSet selectContactByCname(final String cid,final String cname,final Connection connection) throws Exception;
	public abstract ResultSet selectContactByCid(final String cid,final Connection connection) throws Exception;
	public abstract int updateContact(final Contact contact,final int sid,final Connection connection) throws Exception;
	public abstract int deleteContactBySid(final int sid,final Connection connection)throws Exception;
	public abstract ResultSet selectAllContact(final Connection connection) throws Exception;
	public abstract ResultSet selectContactBySid(final int sid,final Connection connection) throws Exception;

}
