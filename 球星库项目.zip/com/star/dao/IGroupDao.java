package com.star.dao;

import java.sql.Connection;
import java.sql.ResultSet;

import com.star.pojo.Group;


public interface IGroupDao {
	public abstract int insertGroups(final Group group,final Connection connection)throws Exception;
	public abstract ResultSet selectAllGroups(final Connection connection)throws Exception;
	public abstract int updateGroups(final Group group,final int gid,final Connection connection)throws Exception;
	public abstract ResultSet selectGroupByGname(final  int gname,final Connection connection)throws Exception;
}
