package com.star.dao;

import java.sql.Connection;
import java.sql.ResultSet;

import com.star.pojo.Account;

public interface IAccountDao {
	public abstract int insertAccount(final Account account, final Connection connection) throws Exception;

	public abstract ResultSet checkLogin(final Account account, final Connection connection) throws Exception;
	
	public abstract ResultSet selectAllAccount(final Connection connection);

	public abstract int updatePassword(final String pwd,final String cid, final Connection connection) throws Exception;

}
